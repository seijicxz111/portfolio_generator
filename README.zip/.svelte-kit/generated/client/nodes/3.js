import * as universal from "../../../../src/routes/generate/[username]/+page.js";
export { universal };
export { default as component } from "../../../../src/routes/generate/[username]/+page.svelte";